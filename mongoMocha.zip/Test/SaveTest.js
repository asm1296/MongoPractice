const assert = require('assert');
const pokemonModel = require('../models/pokemonmod');


describe('Test cases for Saving records in DB',()=>{
    
        var pikachu = new pokemonModel({
            name : 'Pikachu',
            power : 'Electric'
        });
    

    it('Test Case for saving one record in DB',(done)=>{
        pikachu.save().then(()=>{
            assert(pikachu.isNew === false);
            done();
        }
            
        )
        
    })
});